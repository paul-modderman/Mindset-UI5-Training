jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 PlantSet in the list
// * All 3 PlantSet have at least one PlantToRequests

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/mindset/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/mindset/test/integration/pages/App",
	"com/mindset/test/integration/pages/Browser",
	"com/mindset/test/integration/pages/Master",
	"com/mindset/test/integration/pages/Detail",
	"com/mindset/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.mindset.view."
	});

	sap.ui.require([
		"com/mindset/test/integration/MasterJourney",
		"com/mindset/test/integration/NavigationJourney",
		"com/mindset/test/integration/NotFoundJourney",
		"com/mindset/test/integration/BusyJourney",
		"com/mindset/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});