sap.ui.define([
	"com/mindset/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function(BaseController, History, MessageToast) {
	"use strict";


	return BaseController.extend("com.mindset.controller.Add", {


		onInit: function() {
			this.getRouter().getRoute("add").attachPatternMatched(this._onRouteMatched, this);
		},


		_onRouteMatched: function() {
			var oModel = this.getModel();
			oModel.setDefaultBindingMode("TwoWay");
			oModel.metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},


		_onMetadataLoaded: function() {
			
			var oProperties = {
//				Equipment: "PAUL TESTING"
			};


			this._oContext = this.getModel().createEntry("/MaintRequestSet", {
				properties: oProperties,
				success: this._onCreateSuccess.bind(this)
			});


			// bind the view to the new entry
			this.getView().setBindingContext(this._oContext);
		},
		
		_onCreateSuccess: function(oMaintRequest){
			//unbind the view to not show this object again
			this.getView().unbindObject();
			
			//show success message
			var sMessage = this.getResourceBundle().getText("newObjectCreated", [oMaintRequest.ShortText]);
			MessageToast.show(sMessage, {
				closeOnBrowserNavigation: false
			});
		},


		onCancel: function() {
			this.onNavBack();
		},


		onSave: function() {
			this.getModel().submitChanges();
		},


		onNavBack: function() {
			// discard new product from model.
			this.getModel().deleteCreatedEntry(this._oContext);


			var oHistory = History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash();


			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				// Otherwise we go backwards with a forward history
				var bReplace = true;
				this.getRouter().navTo("worklist", {}, bReplace);
			}
		}


	});
});