sap.ui.define([
	"com/mindset/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
],  function(BaseController, History, MessageToast){
		"use strict";
		
		return BaseController.extend("com.mindset.controller.Display", {
			
			onInit: function(){
				this.getRouter().getRoute("display").attachPatternMatched(this._onRouteMatched, this);	
			},
			
			_onRouteMatched: function(oEvent){
				var oModel = this.getModel();
				var sObjectId = oEvent.getParameter("arguments").objectId;
				oModel.setDefaultBindingMode("TwoWay");
				oModel.metadataLoaded().then(function(){
					var sObjectPath = this.getModel().createKey("MaintRequestSet", {
						NotificationNo: sObjectId	
					});
					this.getView().bindElement({ path: "/" + sObjectPath });
				}.bind(this));
			},
			
			onCancel: function(){
				//this.onNavBack();
				history.go(-1);
			},
			
			onSave: function(){
				var sPath = this.getView().getBindingContext().sPath;
				var oChangedObject = this.getModel().getObject(sPath);
				this.getModel().update(sPath, oChangedObject);
			},
			
			onDelete: function(){
				var sPath = this.getView().getBindingContext().sPath;
				this.getModel().remove(sPath);				
			}
			
		});
	}
);