jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/mindset/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/mindset/test/integration/pages/App",
	"com/mindset/test/integration/pages/Browser",
	"com/mindset/test/integration/pages/Master",
	"com/mindset/test/integration/pages/Detail",
	"com/mindset/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.mindset.view."
	});

	sap.ui.require([
		"com/mindset/test/integration/NavigationJourneyPhone",
		"com/mindset/test/integration/NotFoundJourneyPhone",
		"com/mindset/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});